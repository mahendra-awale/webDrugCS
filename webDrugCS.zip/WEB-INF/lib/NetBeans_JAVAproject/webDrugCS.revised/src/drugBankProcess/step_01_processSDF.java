/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drugBankProcess;

import chemaxon.marvin.calculations.MajorMicrospeciesPlugin;
import chemaxon.reaction.Standardizer;
import chemaxon.reaction.StandardizerException;
import chemaxon.struc.Molecule;
import chemaxon.util.MolHandler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//=============================================================================//
/**
 *
 * @author mahendra
 */
public class step_01_processSDF {

    //==========================================================================//
    static MajorMicrospeciesPlugin mmp = new MajorMicrospeciesPlugin();

    public static void main(String args[]) throws IOException, StandardizerException {

        if (args.length == 0) {

            System.out.println("*************************************************************************************");
            System.out.println("USAGE:-");
            System.out.println("java -cp PATHtoJARFile/Applications.jar step_01_processSDF inFile.sdf outFile.smi");
            System.out.println("*************************************************************************************");
        }

        FileReader fr = new FileReader(args[0]);
        BufferedReader br = new BufferedReader(fr);

        FileWriter fw = new FileWriter(args[1]);
        BufferedWriter bw = new BufferedWriter(fw);

        String line = "";
        Molecule mol;
        String sMol = "";

        /*Its not the good way to DO:Rather one can used config file:well
         doesnt matter now*/

        Standardizer st1 = new Standardizer("clearisotopes");
        Standardizer st2 = new Standardizer("neutralize");

        double successFullyWriteMol = 0;
        double totalNumberOfMolReadSoFar = 0;

        while ((line = br.readLine()) != null) {

            sMol = sMol + line + "\n";
            if (line.contains("$$$$")) {
                String smi = "";

                try {

                    totalNumberOfMolReadSoFar++;
                    mol = new MolHandler(sMol).getMolecule();
                    mol = st1.standardize(mol);
                    mol = st2.standardize(mol);

                    Molecule[] convertToFrags = mol.convertToFrags();
                    int max = 0;
                    int atmcount = 0;
                    int winner = 0;
                    for (int k = 0; k < convertToFrags.length; k++) {
                        atmcount = convertToFrags[k].getAtomCount();
                        if (atmcount > max) {
                            max = atmcount;
                            winner = k;
                        }
                    }

                    mol = convertToFrags[winner];
                    mol = harmonize(mol);
                    if (mol == null) {
                        sMol = "";
                        continue;
                    }

                    mol = majorSpecies(mol);
                    if (mol == null) {
                        sMol = "";
                        continue;
                    }

                    smi = mol.toFormat("smiles:u0-H");
                    String dbID = "NotGiven";

                    String tmp[] = sMol.split("\n");
                    for (int i = 0; i < tmp.length; i++) {

                        if (tmp[i].contains("DRUGBANK_ID")) {
                            dbID = tmp[i + 1];
                            break;
                        }
                    }

                    int atmCount = mol.getAtomCount();
                    if (atmCount > 50) {
                        sMol = "";
                        continue;
                    }

                    bw.write(smi + " " + dbID);
                    bw.newLine();
                    successFullyWriteMol++;

                } catch (Exception e) {
                    sMol = "";
                    continue;
                }

                sMol = "";

                if (successFullyWriteMol != 0 && (successFullyWriteMol % 10000) == 0.0) {
                    System.out.println("TOTAL MOLECULES READ SO FAR " + (int) totalNumberOfMolReadSoFar);
                    System.out.println("TOTAL MOLECULES EXPORTED SO FAR " + (int) successFullyWriteMol);
                }
            }
        }

        bw.close();
        br.close();

        System.out.println("===========================================================");
        System.out.println("\nTOTAL MOLECULES READ " + (int) totalNumberOfMolReadSoFar);
        System.out.println("TOTAL MOLECULES EXPORTED " + (int) successFullyWriteMol);
        System.out.println("TOTAL MOLECULES FAILED " + (int) (totalNumberOfMolReadSoFar - successFullyWriteMol));
        System.out.println("OUTPUT FILE " + args[0] + ".smi");
        System.out.println("===========================================================");
        System.out.println("END");
    }
    //=========================================================================//
    /* Do a valence check, dehydrogenize and dearomatize mol*/

    public static Molecule harmonize(Molecule m) {
        m.valenceCheck();
        if (m.hasValenceError()) {
            System.err.println("VALENCE ERROR " + m.toFormat("smiles"));
            return null;
        }

        m.hydrogenize(false);
        m.aromatize();
        if (!m.dearomatize()) {
            System.err.println("DEAROMATIZE ERROR " + m.toFormat("smiles"));
            return null;
        }
        return m;
    }

    //=========================================================================//
    /* to pH 7.4*/
    public static Molecule majorSpecies(Molecule m) {
        try {
            mmp.setMolecule(m);
            mmp.setpH(7.4);
            mmp.run();
            m = mmp.getMajorMicrospecies();
        } catch (Exception e) {
            e.toString();
            System.err.println("MMP ERROR " + m.toFormat("smiles"));
            return null;
        }
        return m;
    }
    //=========================================================================//
}
