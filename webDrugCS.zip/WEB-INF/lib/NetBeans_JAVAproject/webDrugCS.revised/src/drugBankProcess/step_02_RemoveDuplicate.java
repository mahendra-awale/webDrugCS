/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drugBankProcess;

import chemaxon.struc.Molecule;
import chemaxon.util.MolHandler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class step_02_RemoveDuplicate {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        //======================================================================
        if (args.length == 0) {

            System.out.println("*************************************************************************************");
            System.out.println("USAGE:-");
            System.out.println("java -cp PATHtoJARFile/Applications.jar step_02_RemoveDuplicate inFile.smi outFile.smi hacLimit");
            System.out.println("hacLimit:0 for no limit");
            System.out.println("*************************************************************************************");
        }
        //======================================================================

        FileReader fr = new FileReader(args[0]);
        BufferedReader br = new BufferedReader(fr);

        FileWriter fw = new FileWriter(args[1]);
        BufferedWriter bw = new BufferedWriter(fw);

        HashMap<String, String> hmMols = new HashMap();
        //======================================================================
        String str;
        while ((str = br.readLine()) != null) {

            String sarray[] = str.split(" ");
            if (hmMols.containsKey(sarray[0])) {

                String get = hmMols.get(sarray[0]);
                String ids[] = get.split(" ");
                boolean control = false;

                for (int a = 0; a < ids.length; a++) {
                    if (ids[a].equals(sarray[1])) {
                        control = true;
                        break;
                    }
                }

                if (control) {
                    System.out.println("DUPLICATE ID MOLECULE FOUND " + sarray[1]);
                    continue;
                }

                hmMols.put(sarray[0], get + "_" + sarray[1]);
                System.out.println("DUPLICATE FOUND " + sarray[0] + " " + sarray[1] + " " + get);
                continue;
            }

            hmMols.put(sarray[0], sarray[1]);
        }
        br.close();
        //======================================================================
        Molecule mol;
        int hacLimit = 0;
        try {
            hacLimit = Integer.valueOf(args[2]);
        } catch (Exception e) {
            hacLimit = 0;
        }
        //======================================================================
        for (String key : hmMols.keySet()) {
            try {

                if (hacLimit == 0) {
                    bw.write(key + " " + hmMols.get(key) + "\n");
                    continue;
                }

                int atomCount = new MolHandler(key).getAtomCount();
                if (atomCount > hacLimit) {
                    continue;
                }
                bw.write(key + " " + hmMols.get(key) + "\n");
            } catch (Exception e) {
                continue;
            }
        }

        bw.close();
        System.out.println("END");
        //======================================================================
    }
}
