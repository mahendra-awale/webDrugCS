/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drugBankProcess;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/**
 *
 * @author mahendra
 */
public class getDrugHTMLfile {

//==============================================================================
    public static void main(String args[]) throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        String str;

        while ((str = br.readLine()) != null) {

            try {
                savePage("http://www.drugbank.ca/drugs/" + str, str, "drugs.html");
            } catch (Exception e) {
                continue;
            }
        }
        
        br.close();
        System.out.println("END");
    }

//==============================================================================
    public static String savePage(final String URL, String inFile, String base) throws IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(base + "/" + inFile+".html"));

        String line = "", all = "";
        URL myUrl = null;
        BufferedReader in = null;
        try {
            myUrl = new URL(URL);
            in = new BufferedReader(new InputStreamReader(myUrl.openStream()));

            while ((line = in.readLine()) != null) {
                bw.write(line + "\n");
            }
        } finally {
            if (in != null) {
                in.close();
            }
        }
        bw.close();
        return all;
    }
//==============================================================================    
}
