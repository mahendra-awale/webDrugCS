/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package APfp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * @author mahendra
 */
public class C_genDataForMap {

    public String coord[];
    public String color[];
    public String asf[];
    public String cpds[];
    public String CORDINATES = "";
    public String COLOR = "";
    public String ASF = "";
    public String CPDS = "";
    public String avgCPDS = "";
    public int numOfCpdsMap = 0;
    boolean boolRGBforMap = false;
    boolean boolRGBforExt = false;

    public void genData(ArrayList<String> mapMols, String inFile, String rgbForMap, String rgbForExtSet, String baseFolder) throws FileNotFoundException, IOException {

        //======================================================================
        HashMap<String, String> hmCoord = new HashMap();
        HashMap<String, String> hmCoolr = new HashMap();
        HashMap<String, String> hmAsf = new HashMap();
        HashMap<String, String> hmCpds = new HashMap();
        HashMap<String, String> indx = new HashMap();
        //======================================================================
        if (!rgbForMap.isEmpty()) {
            String sarray[] = rgbForMap.split("_");
            if (sarray.length == 3) {
                try {
                    int r = Integer.valueOf(sarray[0]);
                    int g = Integer.valueOf(sarray[1]);
                    int b = Integer.valueOf(sarray[2]);
                    boolRGBforMap = true;
                } catch (Exception e) {
                }
            }
        }

        if (!rgbForExtSet.isEmpty()) {
            String sarray[] = rgbForExtSet.split("_");
            if (sarray.length == 3) {
                try {
                    int r = Integer.valueOf(sarray[0]);
                    int g = Integer.valueOf(sarray[1]);
                    int b = Integer.valueOf(sarray[2]);
                    boolRGBforExt = true;
                } catch (Exception e) {
                }
            }
        }
        //======================================================================
        BufferedReader br1 = new BufferedReader(new FileReader(baseFolder+"/" + inFile));
        coord = br1.readLine().split(";");
        color = br1.readLine().split(";");
        asf = br1.readLine().split(";");
        cpds = br1.readLine().split(";");
        avgCPDS = br1.readLine();
        br1.close();
        //======================================================================

        //======================================================================
        for (int a = 0; a < coord.length; a++) {
            hmCoord.put(coord[a], coord[a]);
            if (boolRGBforMap) {
                hmCoolr.put(coord[a], rgbForMap);
            } else {
                hmCoolr.put(coord[a], color[a]);
            }
            hmAsf.put(coord[a], asf[a]);
            hmCpds.put(coord[a], cpds[a]);
            indx.put(a + "", coord[a]);
        }
        //======================================================================

        //======================================================================
        int indxForNewMols = indx.size() - 1;
        for (int a = 0; a < mapMols.size(); a++) {

            String molData = mapMols.get(a);
            String smi = molData.split(" ")[0];
            String id = molData.split(" ")[1];
            String crd = molData.split(" ")[2];
            String rgb = molData.split(" ")[3];
            rgb = rgb.replaceAll("\\r$", "");

            if (hmCoord.containsKey(crd)) {

                if (boolRGBforExt) {
                    hmCoolr.put(crd, rgbForExtSet);
                } else {

                    if (rgb.contains("NULL")) {
                        hmCoolr.put(crd, "51_51_255");
                    } else {
                        try {
                            String sarray[] = rgb.split("_");
                            int r = Integer.valueOf(sarray[0]);
                            int g = Integer.valueOf(sarray[1]);
                            int b = Integer.valueOf(sarray[2]);
                            hmCoolr.put(crd, rgb);
                        } catch (Exception e) {
                            hmCoolr.put(crd, "51_51_255");
                        }
                    }
                }

                String cp = hmCpds.get(crd);
                hmCpds.put(crd, cp + "_Ext-" + id);
                String as[] = hmAsf.get(crd).split("_");
                int freq = Integer.valueOf(as[2]) + 1;
                hmAsf.put(crd, as[0] + "_" + as[1] + "_" + freq);
                numOfCpdsMap++;
            } else {

                indxForNewMols++;
                hmCoord.put(crd, crd);

                if (boolRGBforExt) {
                    hmCoolr.put(crd, rgbForExtSet);
                } else {
                    if (rgb.contains("NULL")) {
                        hmCoolr.put(crd, "51_51_255");
                    } else {
                        try {
                            String sarray[] = rgb.split("_");
                            int r = Integer.valueOf(sarray[0]);
                            int g = Integer.valueOf(sarray[1]);
                            int b = Integer.valueOf(sarray[2]);
                            hmCoolr.put(crd, rgb);
                        } catch (Exception e) {
                            hmCoolr.put(crd, "51_51_255");
                        }
                    }
                }

                hmCpds.put(crd, "Ext-" + id);
                hmAsf.put(crd, "0_0_1");
                indx.put(indxForNewMols + "", crd);
                numOfCpdsMap++;
            }
        }

        for (int a = 0; a <= indxForNewMols; a++) {

            if (a == 0) {
                String crd = indx.get(a + "");
                CORDINATES = hmCoord.get(crd);
                COLOR = hmCoolr.get(crd);
                ASF = hmAsf.get(crd);
                CPDS = hmCpds.get(crd);
            } else {
                String crd = indx.get(a + "");
                CORDINATES = CORDINATES + ";" + hmCoord.get(crd);
                COLOR = COLOR + ";" + hmCoolr.get(crd);
                ASF = ASF + ";" + hmAsf.get(crd);
                CPDS = CPDS + ";" + hmCpds.get(crd);
            }
        }

        CORDINATES = CORDINATES.replace(" ", "");
        COLOR = COLOR.replace(" ", "");
        ASF = ASF.replace(" ", "");
        CPDS = CPDS.replace(" ", "");

        //======================================================================
        //Process CPDS so as EXT molecule is always at the beginning
        //If no ext just return
        if (!CPDS.contains("Ext")) {
            return;
        }

        //If containd Ext then do re-ordering
        String s[] = CPDS.split(";");
        CPDS = "";
        for (int a = 0; a < s.length; a++) {

            String out = "";
            if (s[a].contains("Ext")) {

                String sarray[] = s[a].split("_");
                List list = Arrays.asList(sarray);
                Collections.sort(list);

                out = (String) list.get(list.size() - 1);

                for (int b = list.size() - 2; b >= 0; b--) {
                    out = out + "_" + list.get(b);
                }
            } else {
                out = s[a];
            }

            if (CPDS.isEmpty()) {
                CPDS = out;
            } else {
                CPDS = CPDS + ";" + out;
            }
        }
    }
    //==========================================================================        
}