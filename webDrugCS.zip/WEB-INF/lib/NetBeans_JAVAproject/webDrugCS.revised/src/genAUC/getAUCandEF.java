/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package genAUC;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
//==============================================================================

/**
 *
 * @author mahendra
 */
//==============================================================================
public class getAUCandEF {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader brDB_Ori = new BufferedReader(new FileReader(args[0]));
        BufferedReader brDB_PCspace = new BufferedReader(new FileReader(args[1]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));

        //===========READ DATABASE ORIGINAL=====================//
        String strDB;
        HashMap<String, dbMolContainer> dbMols_Ori = new HashMap();
        HashMap<String, dbMolContainer> dbMols_PCspace = new HashMap();


        while ((strDB = brDB_Ori.readLine()) != null) {

            try {
                String sarray[] = strDB.split(" ");
                String id = sarray[0].split(";")[1];
                double[] db_fPs = getFPs(sarray[1]);
                dbMols_Ori.put(id, new dbMolContainer(id, db_fPs));
            } catch (Exception e) {
                continue;
            }
        }
        brDB_Ori.close();

        while ((strDB = brDB_PCspace.readLine()) != null) {

            try {
                String sarray[] = strDB.split(" ");
                String id = sarray[0].split(";")[1];
                double[] db_fPs = getFPs(sarray[1]);
                dbMols_PCspace.put(id, new dbMolContainer(id, db_fPs));
            } catch (Exception e) {
                continue;
            }
        }
        brDB_PCspace.close();
        System.out.println("DB READING COMPLETED " + dbMols_Ori.size());
        //======================================================================
        for (String key1 : dbMols_Ori.keySet()) {
            dbMolContainer query_Ori = dbMols_Ori.get(key1);
            dbMolContainer query_PCspace = dbMols_PCspace.get(key1);
            ArrayList<molContainer> molsWithDist = new ArrayList();

            for (String key2 : dbMols_Ori.keySet()) {

                dbMolContainer ref_Ori = dbMols_Ori.get(key2);
                dbMolContainer ref_PCspace = dbMols_PCspace.get(key2);

                double cbd_ori = getCBDDistances(query_Ori.fp1, ref_Ori.fp1);
                double cbd_pcspace = getCBDDistances(query_PCspace.fp1, ref_PCspace.fp1);
                molsWithDist.add(new molContainer(key2, cbd_ori, cbd_pcspace));
            }

            //========================SORT AND MAKE ACTIVES=====================
            Collections.sort(molsWithDist);
            ArrayList<String> activeShapeIDs = new ArrayList();
            for (int a = 0; a < 20; a++) {
                activeShapeIDs.add(molsWithDist.get(a).id);
            }
            //========================SORT AND CALCULATE AUC NOW================
            for (int a = 0; a < molsWithDist.size(); a++) {
                molsWithDist.get(a).distanceForSorting = molsWithDist.get(a).dist_02;
            }
            Collections.sort(molsWithDist);

            int totalKnownLigands = activeShapeIDs.size();
            ArrayList<Integer> positionOfLigandInDatabase = new ArrayList();
            int lineCounter = 0;

            for (int a = 0; a < molsWithDist.size(); a++) {

                lineCounter++;
                if (activeShapeIDs.isEmpty()) {
                    continue;
                }

                for (int b = 0; b < activeShapeIDs.size(); b++) {

                    if (molsWithDist.get(a).id.equals(activeShapeIDs.get(b))) {
                        positionOfLigandInDatabase.add(lineCounter);
                        activeShapeIDs.remove(b);
                        break;
                    }
                }
            }
            //==================================================================
            //Now calculation
            int databaseSize = lineCounter;
            double rocSum = 0;
            double efFactor_1 = 0;
            double efFactor_2 = 0;

            for (double i = 0; i <= 100; i = i + 0.1) {

                if (i == 0) {
                    continue;
                }

                //Get the subset of database
                int databaseSubset = (int) (((double) i * databaseSize) / (double) 100);

                //Find how many ligand found within above range
                int numOfActivesFound = 0;
                for (int a = 0; a < positionOfLigandInDatabase.size(); a++) {

                    if (positionOfLigandInDatabase.get(a) <= databaseSubset) {
                        numOfActivesFound++;
                    }
                }

                //calculate % of Active found
                double perctOfActivesFound = ((double) numOfActivesFound / (double) totalKnownLigands) * 100;
                rocSum = rocSum + perctOfActivesFound;
            }

            //==================================================================
            //Get the subset of database
            int databaseSubset = (int) (((double) 0.5 * (double) databaseSize) / (double) 100);

            //Find how many ligand found within above range
            int numOfActivesFound = 0;
            for (int a = 0; a < positionOfLigandInDatabase.size(); a++) {

                if (positionOfLigandInDatabase.get(a) <= databaseSubset) {
                    numOfActivesFound++;
                }
            }
            efFactor_1 = ((double) numOfActivesFound / (double) databaseSubset) / ((double) totalKnownLigands / (double) databaseSize);
            //==============================================================
            //Get the subset of database
            databaseSubset = (int) (((double) 1 * (double) databaseSize) / (double) 100);

            //Find how many ligand found within above range
            numOfActivesFound = 0;
            for (int a = 0; a < positionOfLigandInDatabase.size(); a++) {

                if (positionOfLigandInDatabase.get(a) <= databaseSubset) {
                    numOfActivesFound++;
                }
            }
            efFactor_2 = ((double) numOfActivesFound / (double) databaseSubset) / ((double) totalKnownLigands / (double) databaseSize);
            if (efFactor_2 > 100) {
                efFactor_2 = 100;
            }
            //==================================================================
            double auc = rocSum / 1000;
            bw.write(key1 + " " + auc + " " + efFactor_1 + " " + efFactor_2 + "\n");
            //==================================================================
        }
        bw.close();
        System.out.println("END");
    }

    //=========================get the FPs======================================    
    static double[] getFPs(String line) {

        String fp[] = line.split(";");
        double[] fpd = getStringToDoubleArray(fp);
        return fpd;
    }
    //==========================================================================

    static double[] getStringToDoubleArray(String s[]) {

        double[] out = new double[s.length];
        for (int a = 0; a < s.length; a++) {
            out[a] = Double.valueOf(s[a]);
        }

        return out;
    }
    //==========================================================================

    static double getCBDDistances(double fp1[], double fp2[]) {
        double distance = 0;
        for (int a = 0; a < fp1.length; a++) {
            distance = distance + Math.abs(fp1[a] - fp2[a]);
        }
        return distance;
    }

    //==========================================================================
    static float getEcludianDistance(double vectorA[], double vectorB[]) {

        double distance = 0;
        for (int a = 0; a < vectorA.length; a++) {
            distance = distance + (vectorA[a] - vectorB[a]) * (vectorA[a] - vectorB[a]);
        }

        return (float) Math.sqrt(distance);
    }
    //==========================================================================
}
