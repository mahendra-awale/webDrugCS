/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package genAUC;

/**
 *
 * @author mahendra
 */
public class molContainer implements Comparable<molContainer> {

    //complete xfp string. needed for ... everything.
    public String id;
    //distance to reference. needed for sorting
    public double dist_01;
    public double dist_02;
    public double distanceForSorting;
    public int hac_ofMol = 0;

//==============================================================================    
    public molContainer(String ID, double d1, double d2) {

        id = ID;
        dist_01 = d1;
        dist_02 = d2;
        distanceForSorting = dist_01;
    }
//==============================================================================

    @Override
    public int compareTo(molContainer t) {

        if (distanceForSorting < t.distanceForSorting) {
            return -1;
        }
        if (distanceForSorting > t.distanceForSorting) {
            return 1;
        }
        return 0;
    }
//==============================================================================    
}
