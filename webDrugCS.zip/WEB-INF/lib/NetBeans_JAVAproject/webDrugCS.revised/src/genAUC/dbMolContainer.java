/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package genAUC;

/**
 *
 * @author mahendra
 */
public class dbMolContainer {

    String id;
    double fp1[];
    int hac;

    dbMolContainer(String ID, double[] F1) {
        id = ID;
        fp1 = F1;
    }
}