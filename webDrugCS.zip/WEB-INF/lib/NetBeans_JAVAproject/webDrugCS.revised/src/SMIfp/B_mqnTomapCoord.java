/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMIfp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

//==============================================================================
/**
 * This class will take the "SMILE" of query molecule and calculate MQN or
 * RVanDesc followed by PCA calculation and find out its CO-ordinates on map!
 * class is pretty much simple to understand.
 *
 * @author mahendra
 */
public class B_mqnTomapCoord {

    String db;                          //database name
    int mapSize;                        //map size
    double mc_FParray[];                //Mean Centralized values
    double[] avgs;                      //avg value from database
    double[][] eigenV_loadings;         //Eigen vector loadings
    double[] newPC = new double[3];     //New PC values
    double pcMin;                       //Min value from PC
    double pcMax;                       //Max value from PC
    int mapCoordX;                      //Newly found X co-ordinate on map 
    int mapCoordY;                      //Newly found X co-ordinate on map 
    int mapCoordZ;                      //Newly found X co-ordinate on map 
    public ArrayList<String> molsPlusCoord = new ArrayList();
    public String error="NO PROBS";
    String baseFolder="";

//==============================================================================
    public void setDBandMapSize(String DB, int mapsize, String base) {
        db = DB;
        mapSize = mapsize;
        baseFolder=base;
    }
//==============================================================================
//
//    public static void main(String args[])
//    {
//        B_mqnTomapCoord t=new B_mqnTomapCoord();
////        t.setDBandMapSize("DrugBank", 300);
//        ArrayList<String> al=new ArrayList();
//        al.add("C1CCCCC1"+" "+"A"+"\t"+"10;0;0;0;0;0;0;0;1;0;0;0;0;6;6;0;0;0;0;0;0;0;0;0;0;0;0;0;0;6;0;0;0;0;0;6;0;0;0;0;0;0");
//        t.getCoordForMolecule(al);
//        System.out.println(t.molsPlusCoord.get(0));
//    }
    
    
    //get the co-ordinate for molecule//
    public String getCoordForMolecule(ArrayList<String> molsPlusMQNs) {

        //A) READ AVG FILE
        try {
            readAvgFile();
        } catch (Exception e) {
            System.out.println("ERROR: PROBLEM IN AVERAGE FILE");
            return null;
        }

        //B) READ EIGEN VECTOR FILE
        try {
            readEigenVectors();
        } catch (Exception e) {
            System.out.println("ERROR: PROBLEM IN READING EIGEN VECTORS");
            return null;
        }

        //C) READ TOTALMINMAX FILE 
        try {
            readTotalminMax();
        } catch (Exception e) {
            
            System.out.println("ERROR: PROBLEM IN MINMAX FILE");
            return null;
        }
        
        //D) GO THOUGH EACH MOLECULE
        for (int a = 0; a < molsPlusMQNs.size(); a++) {

            String sarray[] = molsPlusMQNs.get(a).split(" ");
            try {
                meanCentralization(sarray[2]);
            } catch (Exception e) {
                System.out.println("ERROR: PROBLEM IN MEAN CENTRALIZATION");
                continue;
            }

            //Calculate PCs
            try {
                calPC1PC2();
            } catch (Exception e) {
                System.out.println("ERROR: PROBLEM IN PC CALCULATION");
                continue;
            }

            //Calculate PCs
            try {
                getMapCoordinates();
            } catch (Exception e) {
                System.out.println("ERROR: PROBLEM IN PC CALCULATION");
                continue;
            }

            int molCoord[] = new int[3];
            molCoord[0] = mapCoordX;
            molCoord[1] = mapCoordY;
            molCoord[2] = mapCoordZ;

            if (molCoord[0] > mapSize || molCoord[1] > mapSize || molCoord[2] > mapSize) {
                System.out.println("Molecule is Out of Map!\n");
                continue;
            }

            if (molCoord[0] < 0 || molCoord[1] < 0 || molCoord[2] < 0) {
                continue;
            }
            
            molsPlusCoord.add(sarray[0]+" "+sarray[1]+" "+molCoord[0]+"_"+molCoord[1]+"_"+molCoord[2] + " " + sarray[3]);
        }

        return "OK";
    }

//==============================================================================
    /*
     * step 1: MQN or RVan Descriptorscalculation done using calculteMQNonServer
     * class
     */
//==============================================================================    
    /*
     * step 2: read in the avergae file
     */
    private void readAvgFile() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(baseFolder+"/dbases/SMIfp/" + db + "/misc/" + db + ".avgs"));
        String[] avgarr = br.readLine().split(";");
        avgs = new double[avgarr.length];
        for (int i = 0; i < avgs.length; i++) {
            avgs[i] = Double.parseDouble(avgarr[i]);
        }
        br.close();
    }
//==============================================================================

    /*
     * step 3: mean centralization of query MQN data
     */
    private void meanCentralization(String fp) {

        String[] fps = fp.split(";");
        mc_FParray = new double[fps.length];
        for (int i = 0; i < fps.length; i++) {
            mc_FParray[i] = Double.parseDouble(fps[i]);
            mc_FParray[i] = mc_FParray[i] - avgs[i];
        }
    }

//==============================================================================
    /*
     * step 4: read in the eigen vectors 
     */
    private void readEigenVectors() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(baseFolder+"/dbases/SMIfp/" + db + "/misc/" + db + ".eWeV"));
        eigenV_loadings = new double[3][avgs.length];
        for (int i = 0; i < eigenV_loadings.length; i++) {
            String[] rarr = br.readLine().split(" ");
            String[] larr = rarr[1].split(";");
            for (int j = 0; j < eigenV_loadings[i].length; j++) {
                eigenV_loadings[i][j] = Double.parseDouble(larr[j]);
            }
        }
        br.close();
    }

//==============================================================================
    /*
     * step 5a: Find new PCs for molecule:
     */
    private void calPC1PC2() {

        newPC = new double[3];
        for (int i = 0; i < newPC.length; i++) {
            for (int j = 0; j < mc_FParray.length; j++) {
                newPC[i] += (mc_FParray[j] * this.eigenV_loadings[i][j]);
            }
        }
    }
//==============================================================================

    /*
     * step 6: read total min max file and store global pcMin and pcMax
     * 
     */
    private void readTotalminMax() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(baseFolder+"/dbases/SMIfp/" + db + "/misc/" + db + ".totminmax"));
        String[] sarr = br.readLine().split(";| ");
        br.close();


        if (Double.parseDouble(sarr[0]) < Double.parseDouble(sarr[2])) {

            if (Double.parseDouble(sarr[0]) < Double.parseDouble(sarr[4])) {
                pcMin = Double.parseDouble(sarr[0]);
            } else {
                pcMin = Double.parseDouble(sarr[4]);
            }
        } else {

            if (Double.parseDouble(sarr[2]) < Double.parseDouble(sarr[4])) {
                pcMin = Double.parseDouble(sarr[2]);
            } else {
                pcMin = Double.parseDouble(sarr[4]);
            }
        }


        if (Double.parseDouble(sarr[1]) > Double.parseDouble(sarr[3])) {

            if (Double.parseDouble(sarr[1]) > Double.parseDouble(sarr[5])) {
                pcMax = Double.parseDouble(sarr[1]);
            } else {
                pcMax = Double.parseDouble(sarr[5]);
            }
        } else {

            if (Double.parseDouble(sarr[3]) > Double.parseDouble(sarr[5])) {
                pcMax = Double.parseDouble(sarr[3]);
            } else {
                pcMax = Double.parseDouble(sarr[5]);
            }
        }
    }

//==============================================================================
    /*
     * step 7: get the actual co-ordinates of point on map
     */
    private void getMapCoordinates() {

        int size = (mapSize - 1);
        mapCoordX = -1;
        mapCoordY = -1;
        mapCoordZ = -1;

        mapCoordX = (int) (Math.floor((newPC[0] - pcMin) * size / (pcMax - pcMin)));
        mapCoordY = (int) (Math.floor((newPC[1] - pcMin) * size / (pcMax - pcMin)));
        mapCoordZ = (int) (Math.floor((newPC[2] - pcMin) * size / (pcMax - pcMin)));
    }
}
