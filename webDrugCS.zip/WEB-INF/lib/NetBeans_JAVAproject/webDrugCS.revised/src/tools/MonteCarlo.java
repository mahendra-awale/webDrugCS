/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;
 
import static java.lang.Math.random;
 
public class MonteCarlo {
    
  public static double range() {
    //a square with a side of length 2 centered at 0 has 
    //x and y range of -1 to 1
    return (random() * 2) - 1;
  }
 
//  public static double pi(int numThrows){
      
      
//    long inCircle = DoubleStream.generate(
//      //distance from (0,0) = hypot(x, y)
//      () -> hypot(range(), range())
//    )
//      .limit(numThrows)
//      .unordered()
//      .parallel()
//      //circle with diameter of 2 has radius of 1
//      .filter(d -> d < 1)
//      .count()
//    ;
//    return (4.0 * inCircle) / numThrows;
//  }
}
