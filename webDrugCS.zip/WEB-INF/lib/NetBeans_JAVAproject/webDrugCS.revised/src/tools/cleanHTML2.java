/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author mahendra
 */
public class cleanHTML2 {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        //======================================================================
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        String str;
        
        String data="";        
        while ((str = br.readLine()) != null) {
            data=data+str;
        }
        br.close();
        //======================================================================
                
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        
        //====        
        String split1 [] = data.split("<table class=\"drug-table data-table table table-condensed table-bordered\">"); 
        data="<html><body><table class=\"drug-table data-table table table-condensed table-bordered\">"+split1[1];
        
        //====
        String split2 [] = data.split("<tr><th>Structure</th><td><div class=\"structure\">");
        String split3 [] = split2[1].split("</div></div></div></div></div></td></tr>"); 
        data=split2[0]+split3[1];
        
        //====
        String split4[]=data.split("<tr id=\"spectra\"><th class=\"divider\"");
        String split5[]=split4[1].split("<tr id=\"references\"><th class=\"divider\"");
        data=split4[0]+"<tr id=\"references\"><th class=\"divider\""+split5[1]+"\n";
        
        //====
        String split6[]=data.split("<tr><th>ATC Code");
        String split7[]=split6[1].split("<tr id=\"interactions\"><th class=\"divider\"");
        data=split6[0]+""+"<tr id=\"interactions\"><th class=\"divider\""+split7[1];
        
        //====
        String split8[]=data.split("<table class=\"standard\"><tr id=\"comments\"><th class=\"divider\" colspan=\"2\">Comments</th></tr></table><div id=\"disqus_thread\"></div>");
        data=split8[0]+"</div>";        
        data=data+"</body></html>";    
        
        bw.write(data+"\n");             
        bw.close();
        System.out.println("END");
    }
}
