/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class aid02 {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader br1 = new BufferedReader(new FileReader(args[0]));
        BufferedReader br2 = new BufferedReader(new FileReader(args[1]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));

        String str;
        HashMap<String, String> hm = new HashMap();
        while ((str = br2.readLine()) != null) {
            String sarray[] = str.split(" ");
            hm.put(sarray[1], sarray[0] + " " + sarray[1]);
        }
        br2.close();

        while ((str = br1.readLine()) != null) {

            if (hm.containsKey(str)) {
                bw.write(hm.get(str) + "\n");
            } else {
            }

        }
        br1.close();
        bw.close();
        System.out.println("END");
    }
}
