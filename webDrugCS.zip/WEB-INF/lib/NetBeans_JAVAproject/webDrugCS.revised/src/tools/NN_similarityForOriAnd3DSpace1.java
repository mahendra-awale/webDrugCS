/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

//==============================================================================
/**
 *
 * @author mahendra
 *
 */
//==============================================================================
public class NN_similarityForOriAnd3DSpace1 {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader br1 = new BufferedReader(new FileReader(args[0]));
        BufferedReader br2 = new BufferedReader(new FileReader(args[1]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));
        String str1;
        String str2;

        HashMap<String, double[]> hm1_Ori = new HashMap();
        HashMap<String, double[]> hm2_3Dspace = new HashMap();

        while ((str1 = br1.readLine()) != null) {

            //===================================
            str2 = br2.readLine();
            String sarray1[] = str1.split(" ");
            String id1 = sarray1[0].split(";")[1];
            String fp1 = sarray1[1];
            hm1_Ori.put(id1, stringtoDoubleArray(fp1));

            String sarray2[] = str2.split(" ");
            String id2 = sarray2[0].split(";")[1];
            String fp2 = sarray2[1];
            hm2_3Dspace.put(id2, stringtoDoubleArray(fp2));
            //===================================
        }
        br1.close();
        br2.close();
        //======================================================================

        for (String key1 : hm1_Ori.keySet()) {
            
            //Calculate NN in ori space and in 3D space
            ArrayList<container1> alOri = new ArrayList();
            ArrayList<container1> al3DSpace = new ArrayList();

            for (String key2 : hm1_Ori.keySet()) {
                double[] molFP1 = hm1_Ori.get(key1);
                double[] molFP2 = hm1_Ori.get(key2);
                double tani = TaniScalarDistTo(molFP1, molFP2);
                alOri.add(new container1(key2, 1-tani));

                double[] molFP3 = hm2_3Dspace.get(key1);
                double[] molFP4 = hm2_3Dspace.get(key2);
                double ecd = getEcludianDistance(molFP3, molFP4);
                al3DSpace.add(new container1(key2, ecd));
            }

            Collections.sort(alOri);
            Collections.sort(al3DSpace);

            int nnsimilar_count = 0;
            for (int a = 0; a < 10; a++) {
                String qid = alOri.get(a).id;
                for (int b = 0; b < 10; b++) {
                    String rid = al3DSpace.get(b).id;
                    if (rid.equals(qid)) {
                        nnsimilar_count++;
                        break;
                    }
                }
            }
            
            bw.write(key1+" "+nnsimilar_count+"\n");
        }
        bw.close();
        System.out.println("END");
    }

//==============================================================================
    static double[] stringtoDoubleArray(String s) {

        String sarray[] = s.split(";");
        double out[] = new double[sarray.length];

        for (int a = 0; a < sarray.length; a++) {
            out[a] = Double.valueOf(sarray[a]);
        }

        return out;
    }
//==============================================================================

    static double getCBDDistances(double fp1[], double fp2[]) {
        double distance = 0;
        for (int a = 0; a < fp1.length; a++) {
            distance = distance + Math.abs(fp1[a] - fp2[a]);
        }
        return distance;
    }

//==============================================================================
    static float getEcludianDistance(double vectorA[], double vectorB[]) {

        double distance = 0;
        for (int a = 0; a < vectorA.length; a++) {
            distance = distance + (vectorA[a] - vectorB[a]) * (vectorA[a] - vectorB[a]);
        }

        return (float) Math.sqrt(distance);
    }

//==============================================================================
    static double TaniScalarDistTo(double[] refMQNarr, double[] tgtMQNarr) {

        double SUMab = 0;
        double SUMa2 = 0; // query/tgt
        double SUMb2 = 0; // ref
        int Longest = Math.max(refMQNarr.length, tgtMQNarr.length);

        for (int i = 0; i < Longest; i++) {
            SUMab += refMQNarr[i] * tgtMQNarr[i];
            SUMa2 += tgtMQNarr[i] * tgtMQNarr[i];
            SUMb2 += refMQNarr[i] * refMQNarr[i];
        }

        double Tani = (double) SUMab / ((double) SUMa2 + (double) SUMb2 - (double) SUMab);
        return Tani;
    }
//==============================================================================
}
