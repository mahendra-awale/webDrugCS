/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author mahendra
 */
public class test {
    
    public static void main(String args[])
    {
    
        ArrayList<container1> al=new ArrayList();
        al.add(new container1("A", 10));
        al.add(new container1("B", 100));
        al.add(new container1("C", 8));
        al.add(new container1("D", 20));
        
        Collections.sort(al);
        
        for(int a=0;a<al.size();a++)
        {
        
            System.out.println(al.get(a).dist+" "+al.get(a).id);
        }
    
    
    
    }    
}
