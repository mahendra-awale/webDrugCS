/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import chemaxon.formats.MolFormatException;
import chemaxon.struc.Molecule;
import chemaxon.util.MolHandler;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author mahendra
 */
public class getImage implements ImageObserver {

    public getImage(ArrayList<String> molList) throws MolFormatException, IOException {

        for (int a = 0; a < molList.size(); a++) {

            String sarray[] = molList.get(a).split(" ");
            Molecule mol = new MolHandler(sarray[0]).getMolecule();
            Image img = (Image) mol.toObject("image:w200,h200");

            BufferedImage b_img = new BufferedImage(img.getHeight(this), img.getHeight(this), BufferedImage.TYPE_INT_ARGB);
            b_img.getGraphics().drawImage(img, 0, 0, null);
            ImageIO.write(b_img, "png", new File("webapps/v.10/ZINCmols/" + sarray[1].split("_")[0] + ".png"));
        }
    }

    public boolean imageUpdate(Image image, int i, int i1, int i2, int i3, int i4) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
