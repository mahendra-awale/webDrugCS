/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class stressValue01 {
    
//==============================================================================
    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader br1 = new BufferedReader(new FileReader(args[0]));
        BufferedReader br2 = new BufferedReader(new FileReader(args[1]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));
        String outFolder = args[3];
        
        String str;

        HashMap<String, double[]> hmOri = new HashMap();
        HashMap<String, double[]> hmProjection = new HashMap();

        ////////////////////////////////////////////////////////////////////////
        while ((str = br1.readLine()) != null) {
            String sarray1[] = str.split(" ");
            double fp[]=stringtoDoubleArray(sarray1[2]);
            hmOri.put(sarray1[1], fp);
        }
        br1.close();
        
        while ((str = br2.readLine()) != null) {
            String sarray2[] = str.split(" ");
            double fp[]=stringtoDoubleArray(sarray2[2]);
            hmProjection.put(sarray2[1], fp);
        }
        br2.close();
        
        for(String key1:hmOri.keySet())
        {
            ArrayList<Double> al1=new ArrayList();
            ArrayList<Double> al2=new ArrayList();
            
            for(String key2:hmOri.keySet())
            {
                double[] oriFp1 = hmOri.get(key1);
                double[] oriFp2 = hmOri.get(key2);
                
                double[] projFp1 = hmProjection.get(key1);
                double[] projFp2 = hmProjection.get(key2);
               
                double cbd=getCBDDistances(oriFp1, oriFp2);
                double ecDist=getEcludianDistance(projFp1, projFp2);
                
                al1.add(cbd);
                al2.add(ecDist);                           
            }
            
            double corrletionCoefficient = corrletionCoefficient(al1, al2);
            bw.write(key1+" "+(1-corrletionCoefficient)+"\n");
            
            BufferedWriter bwScat = new BufferedWriter(new FileWriter(outFolder + "/" + key1));
            for (int a = 0; a < al1.size(); a++) {

                bwScat.write(al1.get(a) + " " + al2.get(a) + "\n");
            }
            bwScat.close();
        }
        bw.close();
        System.out.println("END");
        ////////////////////////////////////////////////////////////////////////        
    }
//==============================================================================
    static double[] stringtoDoubleArray(String s) {

        String sarray[] = s.split(";");
        double out[] = new double[sarray.length];

        for (int a = 0; a < sarray.length; a++) {
            out[a] = Double.valueOf(sarray[a]);
        }

        return out;
    }
//==============================================================================    

    ///////////////////////Calculate coreletion Coefficient!//////////////////////////
    static double corrletionCoefficient(ArrayList<Double> al1, ArrayList<Double> al2) {

        //Summation X2 and Summation Y2
        double sumX = 0;
        double sumY = 0;
        double sumXsquare = 0;
        double sumYsquare = 0;
        double sumXY = 0;


        for (int a = 0; a < al1.size(); a++) {
            double tmp1 = al1.get(a);
            double tmp2 = al2.get(a);

            sumX = sumX + tmp1;
            sumY = sumY + tmp2;

            sumXsquare = sumXsquare + (tmp1 * tmp1);
            sumYsquare = sumYsquare + (tmp2 * tmp2);
            sumXY = sumXY + tmp1 * tmp2;
        }

        //Now the coreletion coefficient
        double r = ((al1.size() * (sumXY)) - (sumX * sumY))
                / Math.sqrt(((al1.size() * sumXsquare) - sumX * sumX) * ((al1.size() * sumYsquare) - sumY * sumY));

        return r;
    }
    
    //==========================================================================
    
    static double getCBDDistances(double fp1[], double fp2[]) {
        double distance = 0;
        for (int a = 0; a < fp1.length; a++) {
            distance = distance + Math.abs(fp1[a] - fp2[a]);
        }
        return distance;
    }
    //==========================================================================

    static float getEcludianDistance(double vectorA[], double vectorB[]) {

        double distance = 0;
        for (int a = 0; a < vectorA.length; a++) {
            distance = distance + (vectorA[a] - vectorB[a]) * (vectorA[a] - vectorB[a]);
        }

        return (float) Math.sqrt(distance);
    }
    //==========================================================================

    static double TaniScalarDistTo(double[] refMQNarr, double[] tgtMQNarr) {

        double SUMab = 0;
        double SUMa2 = 0; // query/tgt
        double SUMb2 = 0; // ref
        int Longest = Math.max(refMQNarr.length, tgtMQNarr.length);

        for (int i = 0; i < Longest; i++) {
            SUMab += refMQNarr[i] * tgtMQNarr[i];
            SUMa2 += tgtMQNarr[i] * tgtMQNarr[i];
            SUMb2 += refMQNarr[i] * refMQNarr[i];
        }

        double Tani = (double) SUMab / ((double) SUMa2 + (double) SUMb2 - (double) SUMab);
        return Tani;
    }
    
    //==========================================================================
}