package tools;

/**
 *
 * This helper class is a practical container for bins & MOLS & distances and
 * used a bit everywhere in searchDist and extractMol! It implements Comparable
 * to be simply sortable (e.g. Collections.sort() in extractMol).
 *
 * @author mahendra
 */
public class container1 implements Comparable<container1> {

    //==========================================================================
    
    //complete xfp string. needed for ... everything.
    public String id;
    
    //distance to reference. needed for sorting
    public double dist;

    public container1(String x, double d) {
        id = x;
        dist = d;
    }
    //==========================================================================
    //defining this function makes it a real "Comparable", therefore sort() functional.
    @Override
    public int compareTo(container1 arg) {
        if (dist < arg.dist) {
            return -1;
        }
        if (dist > arg.dist) {
            return 1;
        }
        return 0;
    }
}
