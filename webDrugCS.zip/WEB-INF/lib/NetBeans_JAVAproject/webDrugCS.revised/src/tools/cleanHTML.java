/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author mahendra
 */
public class cleanHTML {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        //======================================================================
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        String str;
        ArrayList<String> data = new ArrayList();

        while ((str = br.readLine()) != null) {
            data.add(str);
        }
        br.close();
        //======================================================================

        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        for (int a = 0; a < data.size(); a++) {


            if (a == 0) {
                bw.write(data.get(a));
                continue;
            }

            if (a < 21) {
                continue;
            }

            if (a == 21) {
                
                System.out.println(args[0]);
                String str1 = data.get(a);
                String sarray1[] = str1.split("<table class=\"drug-table data-table table table-condensed table-bordered\">");                                
                String sarray2[]=sarray1[1].split("<tr><th>Structure</th><td><div class=\"structure\">");
                String sarray3[]=sarray2[1].split("</div></div></div></div></div></td></tr>");
                bw.write("<table class=\"drug-table data-table table table-condensed table-bordered\">" + sarray2[0] + sarray3[1]+"\n");
                continue;
            }

            String str1 = data.get(a);

            if (str1.contains("<script type=\"text/javascript\">")) {
                String str2 = data.get(a + 1);

                if (str2.contains("CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE")) {
                    bw.write("</body>" + "\n");
                    bw.write("</html>" + "\n");
                    break;
                }
            }
            
            if (str1.contains("<tr id=\"spectra\"><th class=\"divider\""))
            {
            
                String sarray1[]=str1.split("<tr id=\"spectra\"><th class=\"divider\"");
                String sarray2[]=sarray1[1].split("<tr id=\"references\"><th class=\"divider\"");
                bw.write(sarray1[0]+"<tr id=\"references\"><th class=\"divider\""+sarray2[1]+"\n");
                continue;
            }
            
            if (str1.contains("<tr><th>ATC Code") && !str1.contains("<tr id=\"interactions\"><th class=\"divider\""))
            {
            
                String sarray1[]=str1.split("<tr><th>ATC Code");
                str1=data.get(a+1);
                String sarray2[]=str1.split("<tr id=\"interactions\"><th class=\"divider\"");
                bw.write(sarray1[0]+"\n");
                bw.write("<tr id=\"interactions\"><th class=\"divider\""+sarray2[1]+"\n");                
                continue;
            }
            
            if (str1.contains("<tr><th>ATC Code") && str1.contains("<tr id=\"interactions\"><th class=\"divider\""))
            {
            
                String sarray1[]=str1.split("<tr><th>ATC Code");
                String sarray2[]=sarray1[1].split("<tr id=\"interactions\"><th class=\"divider\"");
                bw.write(sarray1[0]+"\n");
                bw.write("<tr id=\"interactions\"><th class=\"divider\""+sarray2[1]+"\n");                
                continue;
            }
            
            if (str1.contains("<tr id=\"interactions\"><th class=\"divider\""))
            {
            continue;
            }
            
                       
            if (str1.contains("<table class=\"standard\"><tr id=\"comments\"><th class=\"divider\" colspan=\"2\">Comments</th></tr></table><div id=\"disqus_thread\"></div>"))
            {
            
                String sarray[]=str1.split("<table class=\"standard\"><tr id=\"comments\"><th class=\"divider\" colspan=\"2\">Comments</th></tr></table><div id=\"disqus_thread\"></div>");
                bw.write(sarray[0]+"</div>\n");
                continue;
            }
            
            bw.write(str1+"\n");
        }
        bw.close();
        System.out.println("END");
    }
}
