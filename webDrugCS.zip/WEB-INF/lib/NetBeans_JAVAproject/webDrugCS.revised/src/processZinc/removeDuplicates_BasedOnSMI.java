/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

//==============================================================================
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

//==============================================================================
/**
 * @author mahendra
 */
public class removeDuplicates_BasedOnSMI {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        HashMap<String, String> hm = new HashMap();
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        String str;

        while ((str = br.readLine()) != null) {

            String[] split = str.split(" ");

            if (hm.containsKey(split[0])) {

                String s[] = hm.get(split[0]).split(" ");
                String smi = s[0];
                String ids = s[1] + "_" + split[1];
                hm.put(s[0], smi + " " + ids);

            } else {
                hm.put(split[0], split[0] + " " + split[1]);
            }
        }

        br.close();
        System.out.println("FINISH ADDING!..");
        System.out.println("NOW WRITING!..");

        //======================================================================
        for (String key : hm.keySet()) {           
            bw.write(hm.get(key) + "\n");
        }

        bw.close();
        System.out.println("END");
    }
}
//==============================================================================
