/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import chemaxon.marvin.calculations.MajorMicrospeciesPlugin;
import chemaxon.reaction.Standardizer;
import chemaxon.reaction.StandardizerException;
import chemaxon.struc.Molecule;
import chemaxon.util.MolHandler;
import java.io.*;
import java.util.zip.GZIPInputStream;

/**
 *
 * @author mahendra
 *
 */
public class sdfToSmiles_TimeOut {

    static boolean control = false;
    static long currTime;

    public static void main(String args[]) throws IOException {


        sdfToSmiles_TimeOut RUN = new sdfToSmiles_TimeOut();

        if (args.length == 0) {

            System.out.println("*************************************************************************************");
            System.out.println("USAGE:-");
            System.out.println("java -cp PATHtoJARFile/Applications.jar processZinc.sdfToSmiles inFile.sdf outFile.smi");
            System.out.println("*************************************************************************************");
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(args[0]))));
        FileWriter fw = new FileWriter(args[1]);
        BufferedWriter bw = new BufferedWriter(fw);

        String line = "";
        Molecule mol;
        String sMol = "";

        double successFullyWriteMol = 0;
        double totalNumberOfMolReadSoFar = 0;

        while ((line = br.readLine()) != null) {

            sMol = sMol + line + "\n";
            if (line.contains("$$$$")) {
                String smi = "";

                try {

                    totalNumberOfMolReadSoFar++;
                    getMol GET = new getMol(sMol);
                    currTime = System.currentTimeMillis();
                    superThread SUPER = new superThread(GET, currTime);

                    GET.start();
                    SUPER.start();

                    GET.join();
                    SUPER.join();


                    if (GET.control = false) {
                        continue;
                    }

                    String zincID = "NotGiven";
                    String tmp[] = sMol.split("\n");
                    zincID = tmp[0];

                    bw.write(GET.processSMI + " " + zincID);
                    bw.newLine();
                    successFullyWriteMol++;

                } catch (Exception e) {
                    sMol = "";
                    mol = null;
                    continue;
                }

                sMol = "";
                mol = null;

                if (successFullyWriteMol != 0 && (successFullyWriteMol % 10000) == 0.0) {
                    System.out.println("TOTAL MOLECULES READ SO FAR " + (int) totalNumberOfMolReadSoFar);
                    System.out.println("TOTAL MOLECULES EXPORTED SO FAR " + (int) successFullyWriteMol);
                }
            }
        }

        bw.close();
        br.close();

        System.out.println("\nTOTAL MOLECULES READ " + (int) totalNumberOfMolReadSoFar);
        System.out.println("TOTAL MOLECULES EXPORTED " + (int) successFullyWriteMol);
        System.out.println("TOTAL MOLECULES FAILED " + (int) (totalNumberOfMolReadSoFar - successFullyWriteMol));
        System.out.println("OUTPUT FILE " + args[0] + ".smi");
        System.out.println("END");
    }
}

//==============================================================================
class superThread extends Thread {

    getMol T1;
    long TIME;

    superThread(getMol t1, long time) {

        T1 = t1;
        TIME = time;
    }

    @Override
    public void run() {

        while (true) {
            long currentTimeMillis = System.currentTimeMillis();
            if (T1.isAlive()) {

                if ((currentTimeMillis - TIME) > 50000) {

                    T1.stop();
                    break;
                }
            } else {
                break;
            }
        }
    }
}

//==============================================================================
class getMol extends Thread {

    static MajorMicrospeciesPlugin mmp = new MajorMicrospeciesPlugin();
    String smi = null;
    String processSMI = null;
    Molecule mol = null;
    Standardizer st1, st2;
    boolean control = false;

    getMol(String sMol) throws StandardizerException {
        smi = sMol;
        st1 = new Standardizer("clearisotopes");
        st2 = new Standardizer("neutralize");
    }

    @Override
    public void run() {

        try {

            mol = new MolHandler(smi).getMolecule();
            Molecule[] convertToFrags = mol.convertToFrags();
            int max = 0;
            int atmcount = 0;
            int winner = 0;
            for (int k = 0; k < convertToFrags.length; k++) {
                atmcount = convertToFrags[k].getAtomCount();
                if (atmcount > max) {
                    max = atmcount;
                    winner = k;
                }
            }

            mol = convertToFrags[winner];
            mol = st1.standardize(mol);
            mol = st2.standardize(mol);
            mol = harmonize(mol);

            if (mol == null) {
                control = false;
                return;
            }

            mol = takeMjorSpecies(mol, 7.4);

            if (mol == null) {
                control = false;
                return;
            }

            //Convert to Smile
            processSMI = mol.toFormat("smiles:q0-H");
            control = true;

        } catch (Exception e) {
            control = false;
        }

    }

    /**
     * DO VALENCE CHECK, DEAROMATIZED and DEHYDROGENISED MOLECULE
     *
     * @param m
     * @return
     */
    public static Molecule harmonize(Molecule m) {

        m.valenceCheck();

        if (m.hasValenceError()) {
            try {
                System.err.println("VALENCE ERROR " + m.toFormat("smiles"));
                return null;
            } catch (Exception e) {
                System.err.println("VALENCE ERROR ");
                return null;
            }
        }

        m.hydrogenize(false);
        m.aromatize();
        if (!m.dearomatize()) {

            try {
                System.err.println("DEAROMATIZE ERROR " + m.toFormat("smiles"));
                return null;
            } catch (Exception e) {
                System.err.println("DEAROMATIZE ERROR ");
                return null;
            }
        }
        return m;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Method generates the major species for given molecule
     *
     * @param mol
     * @param pH
     * @return
     */
    public static Molecule takeMjorSpecies(Molecule mol, double pH) {
        try {
            mmp.setMolecule(mol);
            mmp.setpH(pH);
            mmp.run();
            mol = mmp.getMajorMicrospecies();
            return mol;
        } catch (Exception e) {
            e.toString();
            try {
                System.err.println("MMP ERROR " + mol.toFormat("smiles"));
                return null;
            } catch (Exception e1) {
                System.err.println("MMP ERROR ");
                return null;
            }
        }
    }
////////////////////////////////////////////////////////////////////////////////

    /**
     *
     * CHECK FOR THE VALENCE ERROR in MOLECULE
     *
     * @param mol
     * @return
     *
     */
    boolean valenceCheck(Molecule mol) {

        mol.valenceCheck();
        if (mol.hasValenceError()) {
            return false;
        }
        return true;
    }
}
