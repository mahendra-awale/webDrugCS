/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import java.io.*;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class vendorPLusSMI {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));

        HashMap<String, String> hm = new HashMap<String, String>();

        //Start reading File
        String str;
        System.out.println("START 1");
        while ((str = br.readLine()) != null) {

            String sarray[] = str.split(" ");
            hm.put(sarray[0], str);
        }
        br.close();

        //Start Reading Another file
        System.out.println("START 2");
        BufferedReader br1 = new BufferedReader(new FileReader(args[1]));
        while ((str = br1.readLine()) != null) {

            String sarray[] = str.split(" ");
            if (hm.containsKey(sarray[1])) {
                String value = hm.get(sarray[1]);
                String newValue = sarray[0] + " " + value;
                hm.remove(sarray[1]);
                hm.put(sarray[1], newValue);
            }
        }
        br1.close();

        //Write Down Back
        System.out.println("WRITING DOWN");
        for (String key : hm.keySet()) {
            bw.write(hm.get(key));
            bw.newLine();
        }
        bw.close();
        System.out.println("END");
    }
}
