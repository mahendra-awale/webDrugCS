/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import java.io.*;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class removeDuplicateMol_ByZINCID {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        HashMap<String, String> hm = new HashMap();
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        String str;

        while ((str = br.readLine()) != null) {
            hm.put(str.split(" ")[1], str);
        }

        br.close();
        System.out.println("FINISH ADDING!..");
        System.out.println("NOW WRITING!..");

        for (String key : hm.keySet()) {
            bw.write(hm.get(key) + "\n");
        }

        bw.close();
        System.out.println("END");
    }
}
