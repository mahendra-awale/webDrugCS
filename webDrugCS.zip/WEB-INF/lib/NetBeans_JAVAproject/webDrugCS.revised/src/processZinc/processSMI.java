/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import chemaxon.reaction.Standardizer;
import chemaxon.reaction.StandardizerException;
import chemaxon.sss.search.SearchException;
import chemaxon.struc.Molecule;
import chemaxon.struc.MoleculeGraph;
import chemaxon.util.MolHandler;
import java.io.*;

/**
 *
 * @author mahendra
 */
public class processSMI {

    public static void main(String args[]) throws IOException, StandardizerException, SearchException {

        Standardizer st = new Standardizer("clearisotopes");

        FileReader fr = new FileReader(args[0]);
        BufferedReader br = new BufferedReader(fr);

        FileWriter fw = new FileWriter(args[1]);
        BufferedWriter bw = new BufferedWriter(fw);

        String str;
        Molecule mol;
        String name = "Noname";
        String smi = "";
        double lineCounter = 0;
        while ((str = br.readLine()) != null) {


            lineCounter++;
            if (lineCounter % 10000 == 0.0) {
                System.out.println("Reading Molecules " + lineCounter);
            }

            name = "Noname";
            String sarry[] = str.split(" ");
            if (sarry.length > 1) {
                name = sarry[1];
            }

            try {

                mol = new MolHandler(str).getMolecule();
                mol = st.standardize(mol);
                /*aromatise dearomatise*/
                mol.dearomatize();
                mol.aromatize(MoleculeGraph.AROM_GENERAL);
                mol.dearomatize();
                mol.hydrogenize(false);

                Molecule[] convertToFrags = mol.convertToFrags();
                int max = 0;
                int atmcount = 0;
                int winner = 0;
                for (int k = 0; k < convertToFrags.length; k++) {
                    atmcount = convertToFrags[k].getAtomCount();
                    if (atmcount > max) {
                        max = atmcount;
                        winner = k;
                    }
                }
                mol = convertToFrags[winner];
                smi = mol.toFormat("smiles:q0-H");

            } catch (Exception e) {
                continue;
            }

            bw.write(smi + " " + name);
            bw.newLine();
        }

        bw.close();
        br.close();
    }
}