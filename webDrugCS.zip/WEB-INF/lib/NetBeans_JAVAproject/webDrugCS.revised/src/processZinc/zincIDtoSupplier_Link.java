/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import java.io.*;
import java.util.HashMap;

/**
 * INPUT:
 *
 * 1) TAB SEPERATED FILE: contains three fields 1)ZINCcodeofMolecule
 * 2)SupplierName 3) Code of Supplier! 2) SPACE SEPERATED FILE: contains two
 * field 1) SMI 2) ZINCids
 *
 * =============================================================================
 *
 * OUTPUT:
 *
 * TAB SEPERATED FILE: 1) SMI 2)ZINCcodeOfMolecule 3) All the suppliers!
 *
 *
 * =============================================================================
 * About Suppliers:
 *
 * Suppliers are group into the 9 Categories:
 *
 * 1)ChemBridge, 2)ChemDiv, 3)Enamine, Enamine-REAL, 4)OTAVA, 5)Princeton
 * BioMolecular Research Princeton NP, 6)Specs, Specs Natural Products, 7)UORSY,
 * 8)VITAS-M, 9) OTHERS!!
 *
 * =============================================================================
 *
 * @author mahendra
 *
 */
public class zincIDtoSupplier_Link {

    public static void main(String args[]) throws FileNotFoundException, IOException {


        //======================================================================
        //READ ZINCids And Supplier
        BufferedReader br1 = new BufferedReader(new FileReader(args[0]));
        String str;
        HashMap<String, String> hm = new HashMap();
        while ((str = br1.readLine()) != null) {

            String[] split = str.split("\t");
            String suppl = returnSupplier(split[1]);
            boolean isKnownSuppl = false;

            if (hm.containsKey(split[0])) {

                String get = hm.get(split[0]);
                String supplList[] = get.split(";");

                for (int a = 0; a < supplList.length; a++) {

                    if (supplList[a].equals(suppl + "_" + split[2])) {
                        isKnownSuppl = true;
                        break;
                    }
                }

                if (isKnownSuppl) {
                    continue;
                }

                get = get + ";" + suppl + "_" + split[2];
                hm.put(split[0], get);
                continue;
            }

            hm.put(split[0], suppl + "_" + split[2]);
        }
        br1.close();

        System.out.println("MAP CREATED!");

        //======================================================================
        BufferedReader br2 = new BufferedReader(new FileReader(args[1]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[2]));
        str = "";

        while ((str = br2.readLine()) != null) {

            String sArray[] = str.split(" ");
            String SUPPLIERS = hm.get(sArray[1]);
            bw.write(sArray[0] + "\t" + sArray[1] + "\t" + SUPPLIERS);
            bw.newLine();
        }

        br2.close();
        bw.close();

        //======================================================================
        System.out.println("END");
    }

    static String returnSupplier(String s) {

        if (s.equals("ChemBridge")) {
            return "ChemBridge";
        }

        if (s.equals("ChemDiv")) {
            return "ChemDiv";
        }

        if (s.equals("Enamine")) {
            return "Enamine";
        }

        if (s.equals("Enamine-REAL")) {
            return "Enamine";
        }

        if (s.equals("Otava")) {
            return "Otava";
        }

        if (s.equals("Princeton BioMolecular Research")) {
            return "Princeton";
        }

        if (s.equals("Princeton NP")) {
            return "Princeton";
        }

        if (s.equals("UORSY")) {
            return "UORSY";
        }

        if (s.equals("Vitas-M")) {
            return "Vitas-M";
        }

        if (s.equals("Specs")) {
            return "Specs";
        }

        if (s.equals("Specs Natural Products")) {
            return "Specs";
        }

        return "OTHERS";
    }
}
