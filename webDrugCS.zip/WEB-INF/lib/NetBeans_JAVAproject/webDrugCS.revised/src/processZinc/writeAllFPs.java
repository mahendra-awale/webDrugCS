/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import static MQN.A_CalcMqn.calculateFingerprint;
import Sfp.FP06_sFP;
import chemaxon.marvin.calculations.ElementalAnalyserPlugin;
import chemaxon.marvin.calculations.HBDAPlugin;
import chemaxon.marvin.calculations.MajorMicrospeciesPlugin;
import chemaxon.marvin.calculations.TPSAPlugin;
import chemaxon.marvin.calculations.TopologyAnalyserPlugin;
import chemaxon.marvin.calculations.logPPlugin;
import chemaxon.struc.MolAtom;
import chemaxon.struc.MolBond;
import chemaxon.struc.Molecule;
import chemaxon.util.MolHandler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import makeFP.makeAPfp;
import makeFP.makexFP;
import processAndSplit.processMolecule;

/**
 *
 * @author mahendra
 */
public class writeAllFPs {

    static HBDAPlugin hbdap = new HBDAPlugin();
    static MajorMicrospeciesPlugin mmp = new MajorMicrospeciesPlugin();
    static TopologyAnalyserPlugin tap = new TopologyAnalyserPlugin();
    static ElementalAnalyserPlugin eap = new ElementalAnalyserPlugin();
    static logPPlugin lpp = new logPPlugin();
    static TPSAPlugin psap = new TPSAPlugin();

    public static void main(String args[]) throws FileNotFoundException, IOException {


        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        String str;

        while ((str = br.readLine()) != null) {

            String smol[] = str.split(" ");

            Molecule m = null;
            try {
                m = new MolHandler(smol[0]).getMolecule();
            } catch (Exception e) {
                continue;
            }

            processMolecule processDBmol = new processMolecule(m);
            String processSuccess = null;
            try {
                processSuccess = processDBmol.process(7.4);
            } catch (Exception ex) {
                continue;
            }

            if (processSuccess == null) {
                continue;
            }

            //==================================================================
            //A))))))))....APfp 
            makeAPfp dbShapeFP = new makeAPfp(processDBmol.mol);
            String isOK;
            try {
                isOK = dbShapeFP.createFP();
            } catch (Exception ex) {
                continue;
            }
            if (isOK == null) {
                continue;
            }

            String apfp = dbShapeFP.arrayToString(dbShapeFP.shapeFPInt, ";");
            //==================================================================

            //B)))))))))....Xfp
            makexFP dbxFP = new makexFP(processDBmol.mol, processDBmol.splittedAtomSets);
            try {
                isOK = dbxFP.createFP();
            } catch (Exception ex) {
                continue;
            }
            if (isOK == null) {
                continue;
            }

            String xfp = dbxFP.arrayToString(dbxFP.shapeFPInt, ";");

            //==================================================================

            //C))))))))....MQN            
            String mqn = "";
            if ((mqn = calculateFingerprint(processDBmol.mol)) == null) {
                System.out.println("H");
                continue;
            }

            //==================================================================

            //C)))))))....SMIfp
            processDBmol.mol.aromatize();
            String smifp = "";
            try {
                smifp = SMIshit.CountCharacters(processDBmol.mol.toFormat("smiles:q-0H"));
            } catch (Exception e) {
                System.out.println("I");
                continue;
            }
            processDBmol.mol.dearomatize();
            //==================================================================

            //E))))))))....Sfp
            FP06_sFP makesfp = new FP06_sFP();
            makesfp.config = "cfp1024-7-2.xml";
            String sfp = null;
            try {
                sfp = makesfp.generateSubStructureFP(processDBmol.mol);
            } catch (Exception ex) {
                ex.printStackTrace();
                continue;
            }

            if (sfp == null) {
                continue;
            }

            bw.write(str + " " + mqn + " " + smifp + " " + apfp + " " + xfp + " " + sfp + "\n");

            //==================================================================
        }
        bw.close();
        br.close();
        System.out.println("END");
    }
    //==========================================================================
    /* Do a valence check, dehydrogenize and dearomatize mol*/

    public static Molecule harmonize(Molecule m) {

        try {
            m.valenceCheck();
            if (m.hasValenceError()) {
                System.err.println("VALENCE ERROR " + m.toFormat("smiles"));
                return null;
            }

            m.hydrogenize(false);
            if (!m.dearomatize()) {
                System.err.println("DEAROMATIZE ERROR " + m.toFormat("smiles"));
                return null;
            }

        } catch (Exception e) {
            System.out.println("ERROR DURING HARMONIZATION");
            return null;
        }
        return m;
    }

    /* to pH 7.4*/
    public static Molecule majorSpecies(Molecule m) {
        try {
            mmp.setMolecule(m);
            mmp.setpH(7.4);
            mmp.run();
            m = mmp.getMajorMicrospecies();
        } catch (Exception e) {
            e.toString();
            System.err.println("MMP ERROR " + m.toFormat("smiles"));
            return null;
        }
        return m;
    }

    /*This code is a mixture of the calcMQN method from the CMC original paper plus some more lines
     for the ASF map properties (logP TPSA rigatoms...) */
    public static String calculateFingerprint(Molecule m) {
        //initialize everything
        try {
            hbdap.setMolecule(m);
            hbdap.run();
            tap.setMolecule(m);
            tap.run();
            eap.setMolecule(m);
            eap.run();
            lpp.setMolecule(m);
            lpp.run();
            psap.setMolecule(m);
            psap.run();
        } catch (Exception e) {
            e.toString();
            System.err.println("CalcPlugin Error " + m.toFormat("smiles"));
            return null;
        }

        /* THIS CODE IS MOSTLY COPIED FROM MQN PAPER */
        //Classic descriptors
        int hbd = hbdap.getDonorAtomCount();
        int hbdm = hbdap.getDonorCount();
        int hba = hbdap.getAcceptorAtomCount();
        int hbam = hbdap.getAcceptorCount();
        int rbc = tap.getRotatableBondCount();

        //Ring properties / ring sizes count
        int r3 = 0, r4 = 0, r5 = 0, r6 = 0, r7 = 0, r8 = 0, r9 = 0, rg10 = 0;
        int[][] sssr = m.getSSSR();
        for (int i = 0; i < sssr.length; i++) {
            switch (sssr[i].length) {
                case 3:
                    r3++;
                    break;
                case 4:
                    r4++;
                    break;
                case 5:
                    r5++;
                    break;
                case 6:
                    r6++;
                    break;
                case 7:
                    r7++;
                    break;
                case 8:
                    r8++;
                    break;
                case 9:
                    r9++;
                    break;
                default:
                    rg10++;
                    break;
            }
        }

        //Atom properties
        int c = 0, f = 0, cl = 0, br = 0, I = 0, thac = 0, asv = 0, adv = 0, atv = 0, aqv = 0,
                cdv = 0, ctv = 0, cqv = 0, p = 0, s = 0, posc = 0, negc = 0,
                afrc = 0, cn = 0, an = 0, co = 0, ao = 0;
        int ringat = 0;
        for (int i = 0; i < m.getAtomCount(); i++) {
            MolAtom at = m.getAtom(i);
            boolean isRingAt = tap.isRingAtom(i);
            if (isRingAt) {
                ringat++;
            }
            if (at.getAtno() != 1) {
                thac++;
            }
            //element counts
            switch (at.getAtno()) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                case 6:
                    c++;
                    break;
                case 7:
                    if (isRingAt) {
                        cn++;
                    } else {
                        an++;
                    }
                    break;
                case 8:
                    if (isRingAt) {
                        co++;
                    } else {
                        ao++;
                    }
                    break;
                case 15:
                    p++;
                    break;
                case 16:
                    s++;
                    break;

                case 9:
                    f++;
                    break;
                case 17:
                    cl++;
                    break;
                case 35:
                    br++;
                    break;
                case 53:
                    I++;
                    break;
            }

            //valency count
            switch (at.getBondCount()) {
                case 0:
                    System.err.println("ATOM WITH NO BONDS ");
                    return null;
                case 1:
                    asv++; //single valent can only be acyclic
                    break;
                case 2:
                    if (isRingAt) {
                        cdv++;
                    } else {
                        adv++;
                    }
                    break;
                case 3:
                    if (isRingAt) {
                        ctv++;
                    } else {
                        atv++;
                    }
                    break;
                case 4:
                    if (isRingAt) {
                        cqv++;
                    } else {
                        aqv++;
                    }
                    break;
            }
            if (tap.getRingCountOfAtom(i) > 1) {
                afrc++;
            }
        }

        //Bond properties
        int csb = 0, cdb = 0, ctb = 0, asb = 0, adb = 0, atb = 0, bfrc = 0;
        for (int i = 0; i < m.getBondCount(); i++) {
            MolBond bd = m.getBond(i);
            if (tap.isRingBond(i)) {
                switch (bd.getType()) {
                    case 1:
                        csb++;
                        break;
                    case 2:
                        cdb++;
                        break;
                    case 3:
                        ctb++;
                        break;
                    default:
                        System.err.println("UNKNOWN CYCLIC BOND TYPE " + bd.getType());
                        return null;
                }
            } else {
                switch (bd.getType()) {
                    case 1:
                        asb++;
                        break;
                    case 2:
                        adb++;
                        break;
                    case 3:
                        atb++;
                        break;
                    default:
                        System.err.println("UNKNOWN ACYCLIC BOND TYPE " + bd.getType());
                        return null;
                }
            }
        }

        //bond's fused ring count
        int[][] sssre = m.getSSSRBonds();
        int[] brc = new int[m.getBondCount()];
        for (int j = 0; j < sssre.length; j++) {
            for (int k = 0; k < sssre[j].length; k++) {
                brc[sssre[j][k]]++;
            }
        }
        for (int j = 0; j < brc.length; j++) {
            if (brc[j] > 1) { //if bond's ring count > 1
                bfrc++; //increase fused ring bonds count
            }
        }

        for (int i = 0; i < m.getAtomCount(); i++) {
            int crg = m.getAtom(i).getCharge();
            if (crg > 0) {
                posc += crg;
            }
            if (crg < 0) {
                negc += Math.abs(crg);
            }
        }

        /* END OF COPY PARTY*/
        //now before return put all mqns into sum array (will be used for value-average calcualtion
        //in next step B_MergeSumsToAvg)

        return //first block is MQNs
                //CLASSIC PROPERTIES
                hbd + ";" //hydrogen bond donor atom count 1
                + hbdm + ";" //HBD with multivalency 2
                + hba + ";" //hydrogen bond acceptor atom count 3
                + hbam + ";" //HBA with multivalency 4
                + rbc + ";" //rotatable bond count 5
                //RING PROPERTIES Counts 6-13
                + r3 + ";" + r4 + ";" + r5 + ";" + r6 + ";" + r7 + ";" + r8 + ";" + r9 + ";" + rg10 + ";" //ATOM PROPERTIES
                + thac + ";"//total heavy atom count (= everything else than H D T) 14
                + c + ";" //carbon count 15
                + p + ";"//phosphorus 16
                + s + ";"//sulfur atom count 17
                + f + ";" //fluor atom count 18
                + cl + ";" //chlorine atom count 19
                + br + ";" //bromine atom count 20
                + I + ";" //iodine atom count 21
                + cn + ";" //cyclic nitrogen count 22
                + an + ";" //acyclic nitrogen count 23
                + co + ";" //cyclic oxygen count 24
                + ao + ";" //acyclic oxygen count 25
                + asv + ";"//acyclic single valent atom count 26
                + adv + ";"//acyclic double valent atom count 27
                + atv + ";"//acyclic triple valent atom count 28
                + aqv + ";"//acyclic quart valent atom count 29
                + cdv + ";"//cyclic double valent atom count 30
                + ctv + ";"//cyclic triple valent atom count 31
                + cqv + ";"//cyclic quart valent atom count 32
                + afrc + ";"//atoms-in-fused-ring count 33
                + posc + ";" // Positive charges 34
                + negc + ";" // Negative charges 35
                //BOND PROPERTIES
                + csb + ";"//cyclic single bonds 36
                + cdb + ";"//cyclic double bonds 37
                + ctb + ";"//cyclic triple bonds 38
                + asb + ";"//acyclic singe bonds 39
                + adb + ";"//acyclic double bonds 40
                + atb + ";"//acyclic triple bonds 41
                + bfrc;
    }
}

class SMIshit {

    public static String CountCharacters(String SMILES)
            throws Exception {


        int BrkRndOp = 0, BrkSqrOp = 0; /*Brackets*/
        boolean SqrBrk = false; /*keeps track whether an Square Bracket is currently Open*/
        int SB = 0, DB = 0, TB = 0; /*Bond types*/
        int ChargePlus = 0, ChargeMinus = 0; /*Charges*/
        int AtomB = 0, AtomC = 0, AtomN = 0, AtomO = 0, AtomP = 0, AtomS = 0, AtomF = 0, AtomCl = 0, AtomBr = 0, AtomI = 0, AtomH = 0;
        int Atomc = 0, Atomo = 0, Atoms = 0, Atomn = 0, Atomp = 0;
        int AtomOther = 0;
        /*Rings*/
        int[] RingIdx = new int[9];
        for (int i = 0; i < RingIdx.length; i++) {
            RingIdx[i] = 0;
        }
        int PerCent = 0;



        for (int i = 0; i < SMILES.length(); i++) {

            char ThisChar = SMILES.charAt(i);
            char NextChar;
            if (i != (SMILES.length() - 1)) {
                NextChar = SMILES.charAt(i + 1);
            } else {
                NextChar = ' ';
            }

            /*Check for Letters, this might be alittle tricky, cause one has
             * also to check the next Letter, and just around with i */

            /* Without Square Brackets, only the following Atoms are allowed:
             *
             * B,C,N,O,P,S,F,Cl,Br,I
             *
             * and ofcourse also their aromatic Version:
             *
             * c,n,o,s
             */
            if (!SqrBrk) {
                /*Atoms First*/
                if (ThisChar == 'C') {
                    if (NextChar == 'l') {
                        AtomCl++;
                        i++;
                    } else {
                        AtomC++;
                    }
                } else if (ThisChar == 'B') {
                    if (NextChar == 'r') {
                        AtomBr++;
                        i++;
                    } else {
                        AtomB++;
                    }
                } else if (ThisChar == 'N') {
                    AtomN++;
                } else if (ThisChar == 'O') {
                    AtomO++;
                } else if (ThisChar == 'P') {
                    AtomP++;
                } else if (ThisChar == 'S') {
                    AtomS++;
                } else if (ThisChar == 'F') {
                    AtomF++;
                } else if (ThisChar == 'I') {
                    AtomI++;
                } else if (ThisChar == 'c') {
                    Atomc++;
                } else if (ThisChar == 'o') {
                    Atomo++;
                } else if (ThisChar == 's') {
                    Atoms++;
                } else if (ThisChar == 'n') {
                    Atomn++;
                } else if (ThisChar == 'p') {
                    Atomp++;
                } /*     */ else if (ThisChar == '(') { /*Brackets*/
                    BrkRndOp++;
                } else if (ThisChar == '[') {
                    BrkSqrOp++;
                    SqrBrk = true;
                } else if (ThisChar == '=') { /*Bonds*/
                    DB++;
                } else if (ThisChar == '#') {
                    TB++;
                } else if (ThisChar == '1') { /*Eings*/
                    RingIdx[0]++;
                } else if (ThisChar == '2') {
                    RingIdx[1]++;
                } else if (ThisChar == '3') {
                    RingIdx[2]++;
                } else if (ThisChar == '4') {
                    RingIdx[3]++;
                } else if (ThisChar == '5') {
                    RingIdx[4]++;
                } else if (ThisChar == '6') {
                    RingIdx[5]++;
                } else if (ThisChar == '7') {
                    RingIdx[6]++;
                } else if (ThisChar == '8') {
                    RingIdx[7]++;
                } else if (ThisChar == '9') {
                    RingIdx[8]++;
                } else if (ThisChar == '0') {
                    RingIdx[9]++;
                } else if (ThisChar == '%') {
                    PerCent++;
                    i += 2;
                } else if (ThisChar == '-') {
                    SB++;
                }
            } else if (SqrBrk) {

                if (ThisChar == ']') {
                    SqrBrk = false;
                } else if (ThisChar == '-') {
                    if ('1' <= NextChar && NextChar <= '9') {
                        ChargeMinus += NextChar - '0';
                    } else {
                        ChargeMinus++;
                    }

                } else if (ThisChar == '+') {
                    if ('1' <= NextChar && NextChar <= '9') {
                        ChargePlus += NextChar - '0';
                    } else {
                        ChargePlus++;
                    }

                } else if (isSmallLetter(ThisChar)) {
                    if (ThisChar == 'o') {
                        Atomo++;
                    } else if (ThisChar == 'c') {
                        Atomc++;
                    } else if (ThisChar == 'n') {
                        Atomn++;
                    } else if (ThisChar == 'p') {
                        Atomp++;
                    } else if (ThisChar == 's') {
                        Atoms++;
                    }
                } else if (isCaptialLetter(ThisChar)) {
                    if (ThisChar == 'C') {
                        if (isSmallLetter(NextChar)) {
                            if (NextChar == 'l') {
                                AtomCl++;
                                i++;
                            } else {
                                AtomOther++;
                                i++;
                            }
                        } else {
                            AtomC++;
                        }
                    } else if (ThisChar == 'B') {
                        if (isSmallLetter(NextChar)) {
                            if (NextChar == 'r') {
                                AtomBr++;
                                i++;
                            } else {
                                AtomOther++;
                                i++;
                            }
                        } else {
                            AtomB++;
                        }
                    } else if (ThisChar == 'N') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomN++;
                        }
                    } else if (ThisChar == 'O') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomO++;
                        }
                    } else if (ThisChar == 'P') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomP++;
                        }
                    } else if (ThisChar == 'S') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomS++;
                        }
                    } else if (ThisChar == 'F') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomF++;
                        }
                    } else if (ThisChar == 'I') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else {
                            AtomI++;
                        }
                    } else if (ThisChar == 'H') {
                        if (isSmallLetter(NextChar)) {
                            AtomOther++;
                            i++;
                        } else if ('1' <= NextChar && NextChar <= '9') {
                            AtomH += NextChar - '0';

                        } else {
                            AtomH++;
                        }
                    } else {
                        AtomOther++;
                        if (isSmallLetter(NextChar)) {
                            i++;
                        }
                    }

                }

            }

        }

        int[] SMIfp = new int[34];

        /*00*/ SMIfp[0] = BrkRndOp; //Only count opening Brackets    /*00*/
        SMIfp[13] = BrkSqrOp; //Only count opening Brackets    /*01*/
        SMIfp[19] = SB;                /*02*/
        SMIfp[2] = DB;                /*03*/
        SMIfp[9] = TB;                /*04*/
        SMIfp[8] = RingIdx[0]; //Ring1/*05*/
        if (RingIdx[0] != 0) {
            SMIfp[8] = RingIdx[0] / 2;
        }
        SMIfp[7] = RingIdx[1]; //Ring2/*06*/
        if (RingIdx[1] != 0) {
            SMIfp[7] = RingIdx[1] / 2;
        }
        SMIfp[10] = RingIdx[2]; //Ring3/*07*/
        if (RingIdx[2] != 0) {
            SMIfp[10] = RingIdx[2] / 2;
        }
        SMIfp[12] = RingIdx[3]; //Ring4/*08*/
        if (RingIdx[3] != 0) {
            SMIfp[12] = RingIdx[3] / 2;
        }
        SMIfp[18] = RingIdx[4]; //Ring5/*09*/
        if (RingIdx[4] != 0) {
            SMIfp[18] = RingIdx[4] / 2;
        }
        SMIfp[22] = RingIdx[5]; //Ring6/*10*/
        if (RingIdx[5] != 0) {
            SMIfp[22] = RingIdx[5] / 2;
        }
        SMIfp[23] = RingIdx[6]; //Ring7/*11*/
        if (RingIdx[6] != 0) {
            SMIfp[23] = RingIdx[6] / 2;
        }

        SMIfp[31] = RingIdx[7]; //Ring8/*12*/
        if (RingIdx[7] != 0) {
            SMIfp[31] = RingIdx[7] / 2;
        }
        SMIfp[32] = RingIdx[8]; //Ring9/*13*/
        if (RingIdx[8] != 0) {
            SMIfp[32] = RingIdx[8] / 2;
        }

        SMIfp[26] = PerCent;          /*14*/
        SMIfp[21] = ChargePlus;       /*15*/
        SMIfp[20] = ChargeMinus;      /*16*/
        SMIfp[28] = AtomB;            /*17*/
        SMIfp[5] = AtomC;             /*18*/
        SMIfp[3] = AtomN;            /*19*/
        SMIfp[1] = AtomO;             /*20*/
        SMIfp[27] = AtomP;            /*21*/
        SMIfp[11] = AtomS;            /*22*/
        SMIfp[24] = AtomF;            /*23*/
        SMIfp[17] = AtomCl;           /*24*/
        SMIfp[25] = AtomBr;           /*25*/
        SMIfp[30] = AtomI;            /*26*/
        SMIfp[4] = Atomc;            /*27*/
        SMIfp[14] = Atomo;            /*28*/
        SMIfp[16] = Atoms;            /*29*/
        SMIfp[6] = Atomn;            /*30*/
        SMIfp[33] = Atomp;            /*31*/
        SMIfp[15] = AtomH;            /*32*/
        SMIfp[29] = AtomOther;        /*33*/

//        A_CalcSMIAndProps.okMolCount++;
//        A_CalcSMIAndProps_noTAGGDB.okMolCount++;
//        A_CalcSMIAndProps_xTagPubChem.okMolCount++;
//        A_CalcSMIAndProps_PubChemExtended.okMolCount++;
//        A_CalcSMIAndProps_PubChemExtended_justSMI.okMolCount++;
        for (int j = 0; j < SMIfp.length; j++) {
//            A_CalcSMIAndProps.sums[j] += SMIfp[j];
//            A_CalcSMIAndProps_noTAGGDB.sums[j] += SMIfp[j];
//            A_CalcSMIAndProps_xTagPubChem.sums[j] += SMIfp[j];
//            A_CalcSMIAndProps_PubChemExtended.sums[j] += SMIfp[j];
//            A_CalcSMIAndProps_PubChemExtended_justSMI.sums[j] += SMIfp[j];
        }

        String ResFP = "";
        for (int k = 0; k < SMIfp.length; k++) {
            ResFP += SMIfp[k] + ";";
        }
        ResFP = ResFP.substring(0, ResFP.length() - 1);

        return ResFP;
    }

    public static int getNonAromC(String FP) {
        String[] splitter = FP.split(";");
        int value = Integer.parseInt(splitter[5]);
        return value;
    }

    public static int getAromC(String FP) {
        String[] splitter = FP.split(";");
        int value = Integer.parseInt(splitter[4]);
        return value;
    }

    public static int getNonAromAtom(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value += Integer.parseInt(splitter[1]);
        value += Integer.parseInt(splitter[3]);
        value += Integer.parseInt(splitter[5]);
        value += Integer.parseInt(splitter[11]);
        value += Integer.parseInt(splitter[17]);
        value += Integer.parseInt(splitter[24]);
        value += Integer.parseInt(splitter[25]);
        value += Integer.parseInt(splitter[27]);
        value += Integer.parseInt(splitter[28]);
        value += Integer.parseInt(splitter[29]);
        value += Integer.parseInt(splitter[30]);
        return value;
    }

    public static int getAromAtom(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value += Integer.parseInt(splitter[4]);
        value += Integer.parseInt(splitter[6]);
        value += Integer.parseInt(splitter[14]);
        value += Integer.parseInt(splitter[16]);
        value += Integer.parseInt(splitter[33]);
        return value;
    }

    public static int getO(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[1]);
        return value;
    }

    public static int getN(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[3]);
        return value;
    }

    public static int getH(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[15]);
        return value;
    }

    public static int getBrackets(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[0]);
        return value;
    }

    public static int getPlusCharge(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[21]);
        return value;
    }

    public static int getOminusN(String FP) {
        String[] splitter = FP.split(";");
        int value = 0;
        value = Integer.parseInt(splitter[1]) - Integer.parseInt(splitter[3]);
        return value;
    }

    public static boolean isCaptialLetter(char Letter) {

        if ('A' <= Letter && Letter <= 'Z') {
            return true;
        }
        return false;
    }

    public static boolean isSmallLetter(char Letter) {

        if ('a' <= Letter && Letter <= 'z') {
            return true;
        }
        return false;
    }
}