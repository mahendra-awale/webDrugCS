/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package processZinc;

import java.io.*;
import java.util.HashMap;

/**
 *
 * @author mahendra
 */
public class zincIDAndVendors {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));

        HashMap<String, String> hm = new HashMap<String, String>();

        //Start reading File
        String str;
        System.out.println("START");
        int k = 0;
        while ((str = br.readLine()) != null) {

            String sarray[] = str.split(" ");
            if (hm.containsKey(sarray[0])) {
                String value = hm.get(sarray[0]);
                String newValue = value + " " + sarray[2] + "_" + sarray[1];
                hm.remove(sarray[0]);
                hm.put(sarray[0], newValue);
                continue;
            }

            hm.put(sarray[0], sarray[2] + "_" + sarray[1]);
        }
        br.close();

        //Write Down Back
        System.out.println("WRITING DOWN");
        for (String key : hm.keySet()) {
            bw.write(key + " " + hm.get(key));
            bw.newLine();
        }
        bw.close();
        System.out.println("END");
    }
}
