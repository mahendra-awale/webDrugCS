#!/bin/bash

##################################################
for fp in Sfp
do

mkdir TEST
for img in $(ls ${fp}_mols)
do
name=$(echo $img | awk 'BEGIN{FS="."} {print $1+1}')
cp ${fp}_mols/$img TEST/${name}.png
done

rm -rf /srv/tomcat/webapps/v.10/${fp}_mols
mv /srv/tomcat/webapps/v.10/TEST /srv/tomcat/webapps/v.10/${fp}_mols
cp back.png /srv/tomcat/webapps/v.10/${fp}_mols/0.png

echo $fp

done
##################################################
